#  React Quiz App 💎

A Simple React Quiz App which contains the 7 MCQ’s which have 4 options in each.

## See it Live [HERE](https://react-quiz-jatin8898.netlify.com/) 

### Version
1.0.0

## 📝 Usage

### Clone this Repo
```
git clone https://github.com/Jatin-8898/react-quiz-app.git
```
### Installation

```sh
$ npm install
```

### ✔️ Run

Then go to http://localhost:8000

```sh
$ npm start
```

